const mysql = require('mysql2');

// Configuración básica de conexión
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'tu_usuario',
  password: 'tu_contraseña',
  database: 'tu_basededatos'
});

// Conectar a la BD
connection.connect(err => {
  if (err) {
    console.error('Error de conexión:', err.stack);
    return;
  }
  console.log('Conectado a MySQL como ID', connection.threadId);
});

// Ejemplo de consulta
connection.query('SELECT 1 + 1 AS solution', (err, results) => {
  if (err) throw err;
  console.log('La solución es:', results[0].solution);
});

// Cerrar conexión cuando termines
connection.end();