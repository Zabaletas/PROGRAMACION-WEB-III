const express = require('express');
const mysql = require('mysql2');
const mysqlPromise = require('mysql2/promise');
const app = express();
const port = 3000;

// Configuración de la base de datos (¡cambia estos valores!)
const dbConfig = {
  host: 'localhost',
  user: 'root',      // Usuario MySQL
  password: '',      // Contraseña MySQL
  database: 'test'   // Nombre de tu base de datos
};

// 1. Conexión Básica
function testBasicConnection() {
  return new Promise((resolve) => {
    const connection = mysql.createConnection(dbConfig);
    const start = Date.now();
    
    connection.connect(err => {
      if (err) {
        resolve({
          type: 'Básica',
          status: 'Error',
          time: Date.now() - start + 'ms',
          error: err.message
        });
        return;
      }
      
      connection.query('SELECT 1 + 1 AS solution', (err, results) => {
        const response = {
          type: 'Básica',
          status: 'OK',
          time: Date.now() - start + 'ms',
          result: results[0].solution
        };
        
        connection.end();
        resolve(response);
      });
    });
  });
}

// 2. Conexión con Promesas
async function testPromiseConnection() {
  const start = Date.now();
  try {
    const connection = await mysqlPromise.createConnection(dbConfig);
    const [rows] = await connection.execute('SELECT 1 + 1 AS solution');
    await connection.end();
    
    return {
      type: 'Promesas',
      status: 'OK',
      time: Date.now() - start + 'ms',
      result: rows[0].solution
    };
  } catch (err) {
    return {
      type: 'Promesas',
      status: 'Error',
      time: Date.now() - start + 'ms',
      error: err.message
    };
  }
}

// 3. Conexión con Pooling
const pool = mysqlPromise.createPool({
  ...dbConfig,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

async function testPoolConnection() {
  const start = Date.now();
  let connection;
  try {
    connection = await pool.getConnection();
    const [rows] = await connection.query('SELECT 1 + 1 AS solution');
    
    return {
      type: 'Pooling',
      status: 'OK',
      time: Date.now() - start + 'ms',
      result: rows[0].solution
    };
  } catch (err) {
    return {
      type: 'Pooling',
      status: 'Error',
      time: Date.now() - start + 'ms',
      error: err.message
    };
  } finally {
    if (connection) connection.release();
  }
}

// Ruta principal que muestra los resultados
app.get('/', async (req, res) => {
  try {
    // Probar las tres conexiones
    const [basic, promise, pool] = await Promise.all([
      testBasicConnection(),
      testPromiseConnection(),
      testPoolConnection()
    ]);

    // Crear HTML con los resultados
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Prueba de Conexiones MySQL</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; }
          h1 { color: #333; }
          .connection { 
            margin: 20px 0; 
            padding: 15px; 
            border-radius: 5px; 
            background: #f5f5f5;
          }
          .success { border-left: 5px solid #4CAF50; }
          .error { border-left: 5px solid #F44336; }
          .time { color: #666; font-size: 0.9em; }
        </style>
      </head>
      <body>
        <h1>Resultados de Conexión MySQL</h1>
        
        <div class="connection ${basic.status === 'OK' ? 'success' : 'error'}">
          <h2>Conexión Básica</h2>
          <p>Estado: <strong>${basic.status}</strong></p>
          ${basic.status === 'OK' 
            ? `<p>Resultado: ${basic.result}</p>` 
            : `<p>Error: ${basic.error}</p>`}
          <p class="time">Tiempo: ${basic.time}</p>
        </div>
        
        <div class="connection ${promise.status === 'OK' ? 'success' : 'error'}">
          <h2>Conexión con Promesas</h2>
          <p>Estado: <strong>${promise.status}</strong></p>
          ${promise.status === 'OK' 
            ? `<p>Resultado: ${promise.result}</p>` 
            : `<p>Error: ${promise.error}</p>`}
          <p class="time">Tiempo: ${promise.time}</p>
        </div>
        
        <div class="connection ${pool.status === 'OK' ? 'success' : 'error'}">
          <h2>Conexión con Pooling</h2>
          <p>Estado: <strong>${pool.status}</strong></p>
          ${pool.status === 'OK' 
            ? `<p>Resultado: ${pool.result}</p>` 
            : `<p>Error: ${pool.error}</p>`}
          <p class="time">Tiempo: ${pool.time}</p>
        </div>
        
        <h3>Configuración usada:</h3>
        <pre>${JSON.stringify(dbConfig, null, 2)}</pre>
      </body>
      </html>
    `;

    res.send(html);
  } catch (err) {
    res.status(500).send(`
      <h1 style="color: red">Error</h1>
      <p>${err.message}</p>
    `);
  }
});

// Iniciar servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
  console.log('Accede a la raíz (/) para ver los resultados de las conexiones');
});