const Producto = require('../models/productoModel');

exports.listar = async (req, res) => {
  try {
    const productos = await Producto.getAll();
    res.render('productos/listar', { productos });
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { mensaje: 'Error al obtener productos' });
  }
};

exports.formCrear = (req, res) => {
  res.render('productos/form', { producto: {}, accion: 'Crear' });
};

exports.crear = async (req, res) => {
  try {
    await Producto.create(req.body);
    res.redirect('/productos');
  } catch (error) {
    console.error(error);
    res.status(500).render('productos/form', { 
      producto: req.body, 
      accion: 'Crear',
      error: 'Error al crear producto'
    });
  }
};

exports.formEditar = async (req, res) => {
  try {
    const producto = await Producto.getById(req.params.id);
    if (!producto) {
      return res.status(404).render('error', { mensaje: 'Producto no encontrado' });
    }
    res.render('productos/form', { producto, accion: 'Editar' });
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { mensaje: 'Error al cargar producto' });
  }
};

exports.editar = async (req, res) => {
  try {
    await Producto.update(req.params.id, req.body);
    res.redirect('/productos');
  } catch (error) {
    console.error(error);
    res.status(500).render('productos/form', { 
      producto: req.body, 
      accion: 'Editar',
      error: 'Error al actualizar producto'
    });
  }
};

exports.eliminar = async (req, res) => {
  try {
    await Producto.delete(req.params.id);
    res.redirect('/productos');
  } catch (error) {
    console.error(error);
    res.status(500).render('error', { mensaje: 'Error al eliminar producto' });
  }
};