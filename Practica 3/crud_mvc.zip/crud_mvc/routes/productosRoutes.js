const express = require('express');
const router = express.Router();
const controller = require('../controllers/productosController');

// Listar todos
router.get('/', controller.listar);

// Formulario crear
router.get('/crear', controller.formCrear);

// Procesar creación
router.post('/', controller.crear);

// Formulario editar
router.get('/editar/:id', controller.formEditar);

// Procesar actualización
router.post('/actualizar/:id', controller.editar);

// Eliminar
router.post('/eliminar/:id', controller.eliminar);

module.exports = router;