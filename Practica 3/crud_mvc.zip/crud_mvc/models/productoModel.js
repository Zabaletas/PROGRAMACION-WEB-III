const pool = require('../database/connection');

const Producto = {
  async getAll() {
    const [rows] = await pool.query('SELECT * FROM productos ORDER BY fecha_creacion DESC');
    return rows;
  },

  async getById(id) {
    const [rows] = await pool.query('SELECT * FROM productos WHERE id = ?', [id]);
    return rows[0];
  },

  async create({ nombre, precio, descripcion }) {
    const [result] = await pool.query(
      'INSERT INTO productos (nombre, precio, descripcion) VALUES (?, ?, ?)',
      [nombre, precio, descripcion]
    );
    return result.insertId;
  },

  async update(id, { nombre, precio, descripcion }) {
    await pool.query(
      'UPDATE productos SET nombre = ?, precio = ?, descripcion = ? WHERE id = ?',
      [nombre, precio, descripcion, id]
    );
  },

  async delete(id) {
    await pool.query('DELETE FROM productos WHERE id = ?', [id]);
  }
};

module.exports = Producto;